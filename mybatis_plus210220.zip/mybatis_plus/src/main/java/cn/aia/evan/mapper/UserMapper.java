package cn.aia.evan.mapper;

import cn.aia.evan.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import jdk.nashorn.internal.objects.annotations.Setter;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author evan
 * @since 2020-12-29
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

    /**
     * find all users
     * @return
     */
    public List<User> findAll();

    /**
     * insert one user
     * @param user
     */
    @Insert("insert into user(uid, name, password, birthday) values ( #{uid}, #{name}, #{password}, #{birthday} )")
    public void addUser(User user);

    /**
     * page divide
     * @param page
     * @param birthday
     * @return
     */
//    @Select("SELECT uid,name FROM user WHERE birthday=#{birthday}")
    @Select("SELECT uid,name, birthday, password FROM user WHERE birthday=#{birthday}")
    IPage<User> selectPageVo(Page<?> page, @Param("birthday") LocalDateTime birthday);


}
