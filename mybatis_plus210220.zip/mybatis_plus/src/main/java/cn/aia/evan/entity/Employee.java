package cn.aia.evan.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;

import java.io.Serializable;
import java.util.Date;

public class Employee implements Serializable {
	@TableId(value = "emp_id", type = IdType.AUTO)
	private int empId;
	private String empName;
    private Date empBirthDay;
	private String empSex;
	private Department dept;
    
    //Getters and Setters
    //consructor

//	public Employee(int empId, String empName, Date empBirthDay, String empSex, Department dept) {
//		this.empId = empId;
//		this.empName = empName;
//		this.empBirthDay = empBirthDay;
//		this.empSex = empSex;
//		this.dept = dept;
//	}


	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Date getEmpBirthDay() {
		return empBirthDay;
	}

	public void setEmpBirthDay(Date empBirthDay) {
		this.empBirthDay = empBirthDay;
	}

	public String getEmpSex() {
		return empSex;
	}

	public void setEmpSex(String empSex) {
		this.empSex = empSex;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Employee{" +
				"empId=" + empId +
				", empName='" + empName + '\'' +
				", empBirthDay=" + empBirthDay +
				", empSex='" + empSex + '\'' +
				", dept=" + dept +
				'}';
	}
}