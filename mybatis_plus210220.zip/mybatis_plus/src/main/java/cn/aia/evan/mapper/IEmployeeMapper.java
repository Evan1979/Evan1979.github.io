package cn.aia.evan.mapper;

import java.util.HashMap;
import java.util.List;

import cn.aia.evan.entity.Employee;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;
import org.springframework.stereotype.Repository;

@Mapper
public interface IEmployeeMapper {
    /*fetchType=FetchType.EAGER，如果是EAGER，那么表示取出这条数据时，
    它关联的数据也同时取出放入内存中,如果是LAZY那么取出这条数据时，它关联的数据并不取出来，
    在同一个session中，什么时候要用，就什么时候取(再次访问数据库)。
    但是，在session外，就不能再取了。用EAGER时，因为在内存里，所以在session外也可以取。*/
    @Results({@Result(column = "emp_id", property = "empId", id = true),//id=true，表示为主键
            @Result(column = "emp_name", property = "empName"),
            @Result(column = "emp_birthday", property = "empBirthDay"),
            @Result(column = "emp_sex", property = "empSex"),
            //dept_id是表dept中的dept_id
            @Result(column = "dept_id", property = "dept", one = @One(select = "cn.aia.evan.mapper.IDepartmentMapper.selectDeptById", fetchType = FetchType.EAGER))})
    @Select("SELECT * FROM employee;")
    public List<Employee> selectEmpsByYears(@Param("obj") HashMap<String, Object> argMap);
    // WHERE emp_BirthDay between #{obj.startTime} and #{obj.endTime}


    @Results({@Result(id=true,column="emp_id",property="empId"),
            @Result(column="emp_name",property="empName"),
            @Result(column="emp_birthday",property="empBirthDay"),
            @Result(column="emp_sex",property="empSex")})
    @Select("SELECT * FROM employee WHERE dept_id=#{deptId};")
    public List<Employee> getEmployeeByDeptId(int deptId);

}