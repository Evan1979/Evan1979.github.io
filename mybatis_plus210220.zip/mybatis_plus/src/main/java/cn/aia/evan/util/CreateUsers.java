package cn.aia.evan.util;

import cn.aia.evan.entity.User;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Random;

public class CreateUsers {

    /**
     * create users
     * into db
     */
    public static User usersGenerator(){


        String[] firstName= new String[]{"evan","tom","flora","ken","mary","kely","ant","gary","lee","brant"};
        String[] lastName= new String[]{"Ma","Xu","Li","Chen","Han","Guo","Fan","Jiang","Wu","Liu"};


        int minD = 1;
        int maxD = 10;
        int first = minD + (int) (Math.random() * (maxD - minD + 1));
        int last = minD + (int) (Math.random() * (maxD - minD + 1));

        String name = firstName[first-1] +" " +lastName[last-1];

//        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String formatDate = simpleDateFormat.format(new Date());

        LocalDateTime date = LocalDateTime.now(); // get the current date


        String password = "123456";
        User user = new User();
        user.setName(name);
        user.setPassword(password);
        user.setBirthday(date);

        return user;

    }

//    public static void main(String[] args) {
//        usersGenerator();
//    }

}
