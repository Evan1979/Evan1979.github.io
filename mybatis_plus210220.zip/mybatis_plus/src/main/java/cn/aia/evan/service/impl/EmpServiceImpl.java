package cn.aia.evan.service.impl;

import cn.aia.evan.entity.Employee;
import cn.aia.evan.mapper.IEmployeeMapper;
import cn.aia.evan.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

/**
 * @Package: cn.aia.evan.service.impl
 * @ClassName: EmpServiceImpl
 * @Author: Evan-QK.Ma@aia.com
 * @Description:
 * @Date: 2/20/2021
 * @Time: 10:42 AM
 */
@Service
public class EmpServiceImpl implements EmpService {
    @Autowired
    IEmployeeMapper iEmployeeMapper;

    @Override
    public List<Employee> selectEmpsByYears(HashMap<String, Object> argMap) {
        return iEmployeeMapper.selectEmpsByYears(argMap);
    }
}
