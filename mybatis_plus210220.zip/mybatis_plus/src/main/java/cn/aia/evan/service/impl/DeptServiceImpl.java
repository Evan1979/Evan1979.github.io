package cn.aia.evan.service.impl;

import cn.aia.evan.entity.Department;
import cn.aia.evan.mapper.IDepartmentMapper;
import cn.aia.evan.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Package: cn.aia.evan.service.impl
 * @ClassName: DeptServiceImpl
 * @Author: Evan-QK.Ma@aia.com
 * @Description:
 * @Date: 2/20/2021
 * @Time: 10:41 AM
 */
@Service
public class DeptServiceImpl implements DeptService {

    @Autowired
    IDepartmentMapper iDepartmentMapper;

    @Override
    public Department selectDeptById(int deptId) {
        return iDepartmentMapper.selectDeptById(deptId);
    }

    @Override
    public Department getDeptById(int deptId) {
        return iDepartmentMapper.getDeptById(deptId);
    }
}
