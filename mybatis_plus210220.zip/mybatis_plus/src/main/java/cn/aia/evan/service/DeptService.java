package cn.aia.evan.service;

import cn.aia.evan.entity.Department;
import cn.aia.evan.entity.User;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author evan
 * @since 2020-12-29
 */
public interface DeptService {

    public Department selectDeptById(int deptId);

    Department getDeptById(int deptId);
}
