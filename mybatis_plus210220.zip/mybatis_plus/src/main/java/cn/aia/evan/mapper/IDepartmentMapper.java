package cn.aia.evan.mapper;

import java.util.List;

import cn.aia.evan.entity.Department;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

@Mapper
public interface IDepartmentMapper {

    @Results({@Result(column = "dept_id", property = "deptId", id = true),
            @Result(column = "dept_name", property = "deptName")})
    @Select(" SELECT * FROM department d WHERE d.dept_id=#{deptId};")
    public Department selectDeptById(int deptId);


    //一对多
    @Results({@Result(id=true,column="dept_id",property="deptId"),
            @Result(column="dept_name",property="deptName"),
            @Result(column="dept_id",property="emps",many=@Many(select="cn.aia.evan.mapper.IEmployeeMapper.getEmployeeByDeptId",fetchType= FetchType.LAZY))})
    @Select("SELECT * FROM department WHERE dept_id=#{deptId};")
    public Department getDeptById(int deptId);

}
