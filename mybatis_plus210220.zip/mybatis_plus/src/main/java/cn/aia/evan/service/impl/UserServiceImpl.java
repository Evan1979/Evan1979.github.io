package cn.aia.evan.service.impl;

import cn.aia.evan.entity.User;
import cn.aia.evan.mapper.UserMapper;
import cn.aia.evan.service.UserService;
import cn.aia.evan.util.CreateUsers;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author evan
 * @since 2020-12-29
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Autowired
    UserMapper userMapper;


    @Override
    public void test(){
        User user = new User();
        user.setUid("27");
        user.setName("Ken Tong");
        userMapper.insert(user);
    }

    @Override
    public IPage<User> getPage(Page<User> page, LocalDateTime birthday) {

        // 分页的大小在配置文件中设置

        // 不进行 count sql 优化，解决 MP 无法自动优化 SQL 问题，这时候你需要自己查询 count 部分
        // page.setOptimizeCountSql(false);
        // 当 total 为小于 0 或者设置 setSearchCount(false) 分页插件不会进行 count 查询
        // 要点!! 分页返回的对象与传入的对象是同一个
        return userMapper.selectPageVo(page, birthday);
    }


    /**
     * 获取全部信息
     */
    @Override
    public List<User> findAll() {
        System.out.println("get all.....UserServiceImpl....");
        List<User> all = userMapper.findAll();
        System.out.println(all);
        return all;
    }


    /**
     * 生成模拟用户
     */
    @Override
    public void addUser() {
        for (int i = 7; i < 27; i++) {
            User user1 = CreateUsers.usersGenerator();
            user1.setUid(String.valueOf(i));
            System.out.println(user1);
            userMapper.addUser(user1);
        }
    }

    /**
     * 读取配置文件信息test
     */
    @Override
    public void getConfigration() {
        System.out.println("finding port....");

    }

}
