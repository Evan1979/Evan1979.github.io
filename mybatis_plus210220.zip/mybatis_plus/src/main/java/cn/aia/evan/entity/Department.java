package cn.aia.evan.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;

import java.util.List;

public class Department {
	@TableId(value = "dept_id", type = IdType.AUTO)
	private int deptId;
	private String deptName;
	private List<Employee> emps;


//
//	public Department(int deptId, String deptName, List<Employee> emps) {
//		this.deptId = deptId;
//		this.deptName = deptName;
//		this.emps = emps;
//	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public List<Employee> getEmps() {
		return emps;
	}

	public void setEmps(List<Employee> emps) {
		this.emps = emps;
	}


	@Override
	public String toString() {
		return "Department{" +
				"deptId=" + deptId +
				", deptName='" + deptName + '\'' +
				", emps=" + emps +
				'}';
	}
}