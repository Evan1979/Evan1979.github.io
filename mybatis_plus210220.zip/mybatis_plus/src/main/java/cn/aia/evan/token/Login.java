package cn.aia.evan.token;

/**
 * @Package: cn.aia.evan.token
 * @ClassName: login
 * @Author: Evan-QK.Ma@aia.com
 * @Description:
 * @Date: 2/8/2021
 * @Time: 10:43 AM
 */
public class Login {
}


