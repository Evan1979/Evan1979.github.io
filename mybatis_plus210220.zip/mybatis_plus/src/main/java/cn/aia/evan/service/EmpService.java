package cn.aia.evan.service;

import cn.aia.evan.entity.Employee;
import cn.aia.evan.entity.User;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author evan
 * @since 2020-12-29
 */
public interface EmpService {


    public List<Employee> selectEmpsByYears(HashMap<String, Object> argMap);
}
