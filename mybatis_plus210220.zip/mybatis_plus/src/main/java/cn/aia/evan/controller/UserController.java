package cn.aia.evan.controller;


import cn.aia.evan.config.WxMpProperties;
import cn.aia.evan.entity.User;
import cn.aia.evan.service.UserService;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

/**
 *
 *
 * @Api()
 * 用于类；表示标识这个类是swagger的资源
 * tags–表示说明
 * value–也是说明，可以使用tags替代
 * 但是tags如果有多个值，会生成多个list
 *
 * @author evan
 * @since 2020-12-29
 */
@Api(value="用户controller",tags={"用户操作接口"})
@RestController
@EnableAutoConfiguration
@RequestMapping("/user")
public class UserController {


    @Value("${server.port}")
    private Integer port;

    @Autowired
    UserService userService;

    @Autowired
    private WxMpProperties wxMpProperties;

    /**
     * get all users's info
     * @ApiOperation() 用于方法；表示一个http请求的操作
     * value用于方法描述
     * notes用于提示内容
     * tags可以重新分组（视情况而用）
     *
     *
     * @return "user List"
     */
    @ApiOperation(value="获取用户信息",tags={"获取用户信息copy(展示页面新设置分组)"},notes="注意查看数据格式是否正确")
    @RequestMapping("/findAll")
    String findAll(){
        List<User> all = userService.findAll ();
//        return "hello";
        return all.toString ();
    }

    /**
     * add one user
     * @return
     */
    @RequestMapping("/add")
    String addAll(){
        userService.addUser();
        return "hello";
    }

    /**
     * get users page by curPage and pageSize
     *
     * @ApiParam() 用于方法，参数，字段说明；表示对参数的添加元数据（说明或是否必填等）
     * name–参数名
     * value–参数说明
     * required–是否必填
     *
     * 注意形参（对象-包装器类型）：
     *     如果参数是非必须的，则会赋值为null，因此参数应该是一个object，它才能接受这个null值。
     * 而上面代码参数page 的类型 为 int，它接受不了null值。
     *
     * 解决方法:
     * 将int 改为 对象类型 Integer :
     * @ApiParam(name="curPage", value = "要获取的页码")
     * @ApiParam(name="size", value = "要获取的页面大小")
     *
     * @param curPage
     * @param size
     * @return
     */
    @RequestMapping(path = "/getPage")
    @ApiOperation(value="获取指定用户信息",tags={"getPages"},notes="注意查看数据格式是否正确")
    List<User> getByPage(Integer curPage, Integer size){
//        int curPage = 1;
//        int size = 2;

        Page<User> UserPage = new Page<>(curPage,size);
        //2020-12-29
        LocalDateTime birthday = LocalDateTime.of(2020, 12, 29,17,30);
        IPage<User> iPage = userService.getPage(UserPage,birthday);
        System.out.println("总页数："+iPage.getPages());
        System.out.println("总记录数："+iPage.getTotal());

        List<User> usersPage = iPage.getRecords();
        usersPage.forEach(System.out::println);

        return usersPage;
    }


    /**
     * get the config info
     */
    @RequestMapping("/getConfig")
    public void readYml() {
        System.out.println("server.port=" + port);
        System.out.println("wxMpProperties=" + JSON.toJSONString(wxMpProperties));
    }

    /**
     * @ApiModel() 用于类 ；表示对类进行说明，用于参数用实体类接收
     * value–表示对象名
     * description–描述
     * 都可省略
     * @ApiModelProperty() 用于方法，字段； 表示对model属性的说明或者数据操作更改
     * value–字段说明
     * name–重写属性名字
     * dataType–重写属性类型
     * required–是否必填
     * example–举例说明
     * hidden–隐藏
     *
     *  @ApiModel(value="user对象",description="用户对象user")
     *  public class User implements Serializable{ private static final long serialVersionUID = 1L; @ApiModelProperty(value="用户名",name="username",example="xingguo") private String username; @ApiModelProperty(value="状态",name="state",required=true) private Integer state; private String password; private String nickName; private Integer isDeleted; @ApiModelProperty(value="id数组",hidden=true) private String[] ids; private List<String> idList; //省略get/set }
     *
     *
     * @ApiIgnore() 用于类或者方法上，可以不被swagger显示在页面上
     * 比较简单, 这里不做举例
     *
     * @ApiImplicitParam() 用于方法
     * 表示单独的请求参数
     * @ApiImplicitParams() 用于方法，包含多个 @ApiImplicitParam
     * name–参数ming
     * value–参数说明
     * dataType–数据类型
     * paramType–参数类型
     * example–举例说明
     *
     *  @ApiOperation("查询测试")
     *  @GetMapping("select")
     *   //@ApiImplicitParam(name="name",value="用户名",dataType="String", paramType = "query") @ApiImplicitParams({ @ApiImplicitParam(name="name",value="用户名",dataType="string", paramType = "query",example="xingguo"), @ApiImplicitParam(name="id",value="用户id",dataType="long", paramType = "query")}) public void select(){ }
     *
     */
    void leanSwagger2Others(){

    }


}
