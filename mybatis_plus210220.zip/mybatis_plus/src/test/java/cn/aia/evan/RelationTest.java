package cn.aia.evan;

import cn.aia.evan.entity.Department;
import cn.aia.evan.entity.Employee;
import cn.aia.evan.mapper.IEmployeeMapper;
import cn.aia.evan.service.DeptService;
import cn.aia.evan.service.EmpService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.HashMap;
import java.util.List;

/**
 * @Package: cn.aia.evan
 * @ClassName: RelationTest
 * @Author: Evan-QK.Ma@aia.com
 * @Description:
 * @Date: 2/20/2021
 * @Time: 10:26 AM
 */


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class RelationTest {

    @Autowired
    EmpService empService;

    @Autowired
    DeptService deptService;


    //一对一，注解
    @Test
    //查询80后的员工有哪些
    public void testSelectEmpsByYears() {
        HashMap<String,Object> argMap = new HashMap<>();
        argMap.put("startTime","1980-01-01");
        argMap.put("endTime","1990-00-00");
        List<Employee> emps = empService.selectEmpsByYears(argMap);
        for(Employee emp : emps) {
            System.out.println(emp);
        }
    }


    //一对多，注解
    @Test
    public void testGetDeptById() {
        int deptId = 1;
        Department dept = deptService.getDeptById(deptId);

        System.out.println(dept);

        List<Employee> emps = dept.getEmps();
        for(Employee emp : emps) {
            System.out.println(emp);
        }
    }

}
