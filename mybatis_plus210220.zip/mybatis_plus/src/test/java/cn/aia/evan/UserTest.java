package cn.aia.evan;

import cn.aia.evan.StartApplication;
import cn.aia.evan.entity.User;
import cn.aia.evan.service.UserService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.time.LocalDateTime;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class UserTest {

    @Autowired
    UserService userService;

    @Test
    public void test1() {
        int curPage = 1;
        int size = 2;

        Page<User> UserPage = new Page<>(1,4);
        //2020-12-29
        LocalDateTime birthday = LocalDateTime.of(2020, 12, 29,17,30);
        IPage<User> iPage = userService.getPage(UserPage,birthday);
        System.out.println("总页数："+iPage.getPages());
        System.out.println("总记录数："+iPage.getTotal());
        List<User> UserList1 = iPage.getRecords();
        UserList1.forEach(System.out::println);
    }

    @Test
    public void test2(){
        User user = new User();
        user.setUid("28");
        user.setName("Ken Tong28");

//        使用的是dao UserMapper实现的接口BaseMapper中的方法
//       userService.test();


//        使用的是service层 IService接口中的api
       userService.save(user);
    }

}
