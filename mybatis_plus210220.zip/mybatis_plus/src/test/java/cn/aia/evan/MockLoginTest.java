package cn.aia.evan;

/**
 * @Package: cn.aia.evan
 * @ClassName: MockLoginTest
 * @Author: Evan
 * @Description:
 * @Date: 2/4/2021 9:24 AM
 * @Version: 1.0
 */
import cn.aia.evan.entity.User;
import cn.aia.evan.mapper.UserMapper;
import cn.aia.evan.service.UserService;
import cn.aia.evan.service.impl.UserServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import static org.mockito.Mockito.*;


//基于MockitoJUnitRunner的运行器
@RunWith(MockitoJUnitRunner.class)
//@RunWith(SpringRunner.class)
@SpringBootTest
public class MockLoginTest {

    //自动将模拟对象或侦查域注入到被测试对象中。
//对被测类中@Autowired的对象，用@Mocks标注；对被测类自己，用@InjectMocks标注
    @InjectMocks
    private UserServiceImpl userService;

    @Mock
    private UserMapper userMapper;

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void loginTest() {

    }


}